"""Interfaz gráfica (PySide6)."""
